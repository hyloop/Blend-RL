
from gym import *


class ImageSensor(sensor.Image, width=64, height=64, camera='Camera'):
    pass
    
    
class TeleportActuator(actuator.Translation, lower=-1, upper=1, object='Cube', local=False):
    pass


class MyAgent(
    Agent,
    sensors=(
        ImageSensor,
    ),
    actuators=(
        TeleportActuator,
    ),
):
    pass


class MyEnvironment(
    Environment
):
    pass


loop = Loop(MyAgent, MyEnvironment)

loop.seed(0)

for e in range(10):
    observation = loop.reset()
    for t in range(100):
        # loop.render()
        print(observation)
        action = loop.action_space.sample()
        observation, reward, done, info = loop.step(action), None, None, None
        if done:
            print(f'Episode finished after {t + 1} time steps. ')
            break

loop.close()

