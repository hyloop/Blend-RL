
def generate(seed, temp) -> None:
    import bpy
    # todo
    bpy.ops.wm.save_as_mainfile(filepath=temp)


if __name__ == '__main__':
    import argparse
    import sys

    parser = argparse.ArgumentParser()
    parser.add_argument('-s', '--seed', type=str, required=True, metavar='SEED', dest='seed')
    parser.add_argument('-t', '--temp', type=str, required=True, metavar='TEMP', dest='temp')

    args = parser.parse_args(sys.argv[sys.argv.index('--') + 1:])

    generate(args.seed, args.temp)

